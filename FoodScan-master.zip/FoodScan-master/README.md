# FoodScan-Master
Master code for FoodScan Android mobile app
